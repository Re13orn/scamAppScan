from mutf8 import decode_modified_utf8, encode_modified_utf8

decode = decode_modified_utf8
encode = encode_modified_utf8